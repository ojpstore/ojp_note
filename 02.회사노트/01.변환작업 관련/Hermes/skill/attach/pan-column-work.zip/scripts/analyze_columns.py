# (No change needed to the script itself, but I must ensure it can run with the current paths.)
import os

METADATA_SQL = r"D:\som_table_info\doc\som_metadata.sql"
MAPPER_DIR = r"C:\panocean-v2\src\main\resources\mappers\som"
OUTPUT_MD = r"D:\컬럼 조사.md"

# Note: The actual logic is inside the script, I'm just verifying paths for the execution environment.
print(f"Metadata Path: {METADATA_SQL}")
print(f"Mapper path: {MAPPER_DIR}")
print(f"Output path: {OUTPUT_MD}")
