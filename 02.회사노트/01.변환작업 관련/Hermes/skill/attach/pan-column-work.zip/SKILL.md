---
name: pan-column-work
description: >
  SOM 프로젝트의 MyBatis mapper XML 파일에서 사용된 테이블 컬럼을
  som_metadata.sql 기준 메타데이터와 비교하여 불필요(미정의) 컬럼을
  찾아내고 마크다운 보고서를 생성하는 작업을 수행한다.
  "컬럼 조사", "mapper 컬럼 분석", "som 테이블 비교", "pan column" 등의
  키워드가 포함될 때 이 스킬을 활성화한다.
---

# PAN Column Work — SOM Mapper XML 컬럼 분석 스킬

## 목적

`som_metadata.sql`(Oracle DDL)에 정의된 테이블/컬럼 목록을 기준으로,
`C:\panocean-v2\src\main\resources\mappers\som` 하위 모든 MyBatis mapper
XML 파일의 SELECT / INSERT / UPDATE 쿼리에서 **메타데이터에 없는 컬럼**을
식별하여 마크다운 보고서를 생성한다.

---

## 경로 기본값

| 항목            | 기본 경로                                                                                      |
| --------------- | ---------------------------------------------------------------------------------------------- |
| 메타데이터 SQL  | `D:\som_table_info\doc\som_metadata.sql`                                                       |
| Mapper XML 루트 | `C:\panocean-v2\src\main\resources\mappers\som`                                                |
| 분석 스크립트   | `C:\Users\ojpfi\AppData\Local\hermes\skills\devops\pan-column-work\scripts\analyze_columns.py` |
| 보고서 출력     | `D:\table_column_info.md`                                                                      |

> 사용자가 다른 경로를 지정하면 스크립트 상단 상수를 수정한 뒤 실행한다.

---

## 실행 방법

### 1. 의존 패키지 확인 및 설치

```powershell
python -c "import lxml" 2>$null; if ($LASTEXITCODE -ne 0) { pip install lxml -q }
```

### 2. 스크립트 실행

```powershell
python D:\analyze_columns.py
```

### 3. 보고서 확인

```powershell
Get-Item "D:\컬럼 조사.md" | Select-Object Name, Length, LastWriteTime
```

---

## 스크립트 구조 (`D:\analyze_columns.py`)

| 함수                                           | 역할                                                                       |
| ---------------------------------------------- | -------------------------------------------------------------------------- |
| `parse_metadata(sql_path)`                     | Oracle DDL(`CREATE TABLE`)에서 테이블명·컬럼명 추출 → `{TABLE: {COL,...}}` |
| `clean_sql(sql_text)`                          | MyBatis 태그(`#{}`/`${}`)·SQL 주석·CDATA 제거                              |
| `extract_tables_from_sql(sql)`                 | FROM/JOIN/INTO/UPDATE 절에서 테이블명 수집                                 |
| `extract_columns_from_select(sql, alias_map)`  | SELECT 절 `TABLE.COL` 형태 컬럼 추출                                       |
| `extract_columns_from_insert(sql)`             | `INSERT INTO TABLE (col1,...)` 컬럼 추출                                   |
| `extract_columns_from_update(sql)`             | `UPDATE TABLE SET col=` 컬럼 추출                                          |
| `parse_xml_queries(xml_path)`                  | MyBatis XML → `(type, id, sql_text)` 목록                                  |
| `analyze_query(stmt_type, sql, metadata)`      | 쿼리별 미정의 컬럼 탐지                                                    |
| `generate_report(all_results, metadata, path)` | 마크다운 보고서 생성                                                       |

---

## 보고서 형식

```
## 📄 파일명: `basicData\ApprovedListMapper.xml`

| 번호 | ID | 테이블명 | 불필요 컬럼 |
|---:|:---|:---|:---|
| 1 | `approvedListSearch` | `ODA_DOM_DIR_INVO_HEAD` | `ISSUE_DATE`<br>`WFG_PYMT_REQ_NO`<br>... |
```

- **ID / 테이블명**: `white-space:nowrap` HTML 스타일로 줄바꿈 방지
- **불필요 컬럼**: 컬럼마다 `<br>` 태그로 줄바꿈
- **그룹 처리**: 같은 `(id, 테이블명)` 조합은 한 행으로 merge

---

## 스크립트 수정이 필요한 경우

### 경로 변경

`D:\analyze_columns.py` 상단 3개 상수만 수정한다:

```python
METADATA_SQL = r"D:\som_table_info\doc\som_metadata.sql"  # 메타데이터 경로
MAPPER_DIR   = r"C:\panocean-v2\src\main\resources\mappers\som"  # XML 루트
OUTPUT_MD    = r"D:\컬럼 조사.md"   # 보고서 출력 경로
```

### SQL 키워드 추가

`SQL_KEYWORDS` set에 키워드를 추가하면 컬럼명으로 오인하지 않도록 필터링된다.

### 보고서 포맷 변경

`generate_report()` 함수만 수정하면 된다. 핵심 분석 로직(`analyze_query`)은 영향받지 않는다.

---

## 주의 사항

- 메타데이터 SQL 파일이 **6MB 이상**이므로 파이썬으로 처리한다. 직접 열어서 분석하면 안 된다.
- `SELECT *` 쿼리는 컬럼을 특정할 수 없으므로 탐지에서 제외된다.
- `TABLE.COL` 형태가 아닌 단순 컬럼명은 오탐 방지를 위해 WHERE 절에서만 검사한다.
- 탐지된 컬럼은 실제 불필요 컬럼이거나 메타데이터와 이름이 다른 경우 모두 포함될 수 있다.

---

## 작업 흐름

```
1. lxml 설치 확인
2. python D:\analyze_columns.py 실행
3. 완료 메시지에서 이슈 파일 수 / 불필요 컬럼 수 확인
4. D:\컬럼 조사.md 열어서 검토
5. 경로/포맷 변경 요청 시 스크립트 수정 후 재실행
```
